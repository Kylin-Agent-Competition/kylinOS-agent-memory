"""D4D Outbox Worker 测试：FR-DB-004 / 附录 B（成功 / 退避 / Dead Letter / 幂等清理）"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

import pytest

from sqlalchemy import func, select

from db import repositories as repo
from db.engine import create_db_engine, init_schema
from outbox.worker import OutboxWorker, _is_schema_missing


@pytest.fixture()
def engine(tmp_path):
    eng = create_db_engine(str(tmp_path / "ow.db"))
    init_schema(eng)
    yield eng
    eng.dispose()


def _enqueue(engine, *, aggregate_id="1", next_retry_at=None):
    with engine.begin() as conn:
        return repo.enqueue_outbox(
            conn,
            aggregate_type="turn",
            aggregate_id=aggregate_id,
            event_type=repo.EVENT_TURN_FINALIZED,
            payload={"turn_id": aggregate_id},
            next_retry_at=next_retry_at or datetime.now(timezone.utc).isoformat(),
        )


def _count(engine):
    with engine.connect() as conn:
        return conn.execute(
            select(func.count()).select_from(repo.outbox)
        ).scalar()


def test_worker_consumes_success(engine):
    _enqueue(engine)
    seen = []

    def consumer(event_type, payload):
        seen.append(payload)

    w = OutboxWorker(engine, poll_interval_s=1, max_retries=3, consumer=consumer)
    w._poll_once()
    # HIGH-01：路由真源 = outbox.event_type 独立列，显式传给 consumer；payload 不注入
    assert seen == [{"turn_id": "1"}]
    assert _count(engine) == 0  # 成功 → DELETE
    w.stop()


def test_worker_no_consumer_retries(engine):
    # Vector 接入未确认（R-9）：无 consumer → 失败路径（attempts+1 + 退避）
    _enqueue(engine)
    w = OutboxWorker(engine, poll_interval_s=1, max_retries=3, consumer=None)
    w._poll_once()
    with engine.connect() as conn:
        row = conn.execute(repo.outbox.select()).mappings().first()
        assert row["attempts"] == 1
        assert row["next_retry_at"] is not None
        assert "no consumer registered" in row["last_error"]
        # 退避 = now + 2^1 * 30s
        next_retry = datetime.fromisoformat(row["next_retry_at"])
        expected_min = datetime.now(timezone.utc) + timedelta(seconds=60 - 5)
        assert next_retry > expected_min
    w.stop()


def test_worker_dead_letter_after_max_retries(engine):
    # 预置 attempts=3（已达 max）且 next_retry_at 已到期 → 再失败 → Dead Letter
    eid = _enqueue(engine)
    with engine.begin() as conn:
        repo.mark_outbox_failure(
            conn, outbox_id=eid, attempts=3,
            next_retry_at=(datetime.now(timezone.utc) - timedelta(seconds=1)).isoformat(),
            last_error="prev",
        )
    w = OutboxWorker(engine, poll_interval_s=1, max_retries=3, consumer=None)
    w._poll_once()
    with engine.connect() as conn:
        row = conn.execute(repo.outbox.select()).mappings().first()
        assert row["attempts"] == 4
        assert row["next_retry_at"] is None  # Dead Letter
    assert w.metrics()["dead_letters"] == 1
    assert _count(engine) == 1  # 不丢事件
    w.stop()


def test_worker_cleans_expired_idempotency(engine):
    now = datetime.now(timezone.utc)
    with engine.begin() as conn:
        repo.write_idempotency_cache(conn, user_id="u1", session_id="s1", idempotency_key="old", response={})
        conn.execute(
            repo.idempotency_cache.update().where(
                repo.idempotency_cache.c.idempotency_key == "old"
            ).values(expires_at=(now - timedelta(hours=1)).isoformat())
        )
    w = OutboxWorker(engine, poll_interval_s=1, max_retries=3)
    w._poll_once()  # 无 pending 事件，但顺带清理过期幂等缓存
    with engine.connect() as conn:
        remaining = conn.execute(
            select(func.count()).select_from(repo.idempotency_cache)
        ).scalar()
    assert remaining == 0
    w.stop()


def test_worker_metrics_backlog(engine):
    _enqueue(engine, aggregate_id="a")
    _enqueue(engine, aggregate_id="b")
    w = OutboxWorker(engine, poll_interval_s=1, max_retries=3)
    m = w.metrics()
    assert m["backlog"] == 2
    assert m["oldest_pending_created_at"] is not None
    w.stop()


def test_worker_start_stop_lifecycle(engine):
    _enqueue(engine)
    w = OutboxWorker(engine, poll_interval_s=1, max_retries=3, consumer=lambda et, p: None)
    w.start()
    w.start()  # 幂等：已启动忽略
    # 等待消费
    deadline = datetime.now(timezone.utc) + timedelta(seconds=5)
    while _count(engine) > 0 and datetime.now(timezone.utc) < deadline:
        import time

        time.sleep(0.1)
    w.stop()
    assert _count(engine) == 0


def test_worker_schema_missing_stops_not_deadloop(tmp_path):
    """表缺失（无 outbox schema）时 Worker 应停止并置 fatal_error，而非无限重试死循环。

    对应 A-REQ-01 死循环：对空库启动 Worker 会撞 `no such table: idempotency_cache`，
    若不处理会对该持久性错误无限重试。修复后应设置 fatal_error 并停止线程。
    """
    assert _is_schema_missing(
        RuntimeError("(sqlite3.OperationalError) no such table: outbox")
    )
    assert not _is_schema_missing(
        RuntimeError("(sqlite3.OperationalError) database is locked")
    )

    # 建一个空库（不 init_schema → 无 outbox/idempotency_cache 表）
    eng = create_db_engine(str(tmp_path / "empty.db"))
    import time

    w2 = OutboxWorker(eng, poll_interval_s=1, max_retries=3)
    w2.start()
    deadline = time.time() + 5
    while w2._thread.is_alive() and time.time() < deadline:
        time.sleep(0.1)
    assert not w2._thread.is_alive(), "schema 缺失时 Worker 应停止（防死循环）"
    assert w2._fatal_error is not None
    assert w2.metrics()["fatal_error"] is not None
    w2.stop()
    eng.dispose()


def test_worker_passes_event_type_to_deletion_consumer(engine):
    """[HIGH-01] worker 将 outbox 行 event_type（forget.executed）显式传给 consumer
    （路由真源 = outbox.event_type 独立列，不注入 payload），
    使删除 consumer 能识别并触发 CacheInvalidator 失效。"""
    # 入队一条 forget.executed 删除事件（payload 不含 event_type，模拟 D 轨 Forget Executor）
    with engine.begin() as conn:
        repo.enqueue_outbox(
            conn,
            aggregate_type="memory",
            aggregate_id="m1",
            event_type=repo.EVENT_FORGET_EXECUTED,
            payload={
                "event_id": "del_001", "user_id": "u1",
                "target_type": "event", "forget_mode": "single_item",
                "content_hashes": ["abc123def456"],
            },
        )
    seen = []
    # 模拟 deletion consumer（HIGH-01 双参约定）：仅记录收到的 event_type，确认 worker 显式传入
    w = OutboxWorker(engine, poll_interval_s=1, max_retries=3,
                     consumer=lambda event_type, payload: seen.append(event_type))
    w._poll_once()
    assert seen == ["forget.executed"], "worker 应将 forget.executed 显式传给 consumer"
    assert _count(engine) == 0  # 消费成功 → DELETE
    w.stop()
