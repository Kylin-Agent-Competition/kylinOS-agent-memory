"""outbox_consumer.py — D11A Outbox → CacheInvalidator 消费桥接

关闭 TD-A-D10-CACHE-INVALIDATION：将 Outbox 删除事件接入 CacheInvalidator。

使用方式：
    from embedding.outbox_consumer import build_deletion_consumer
    consumer = build_deletion_consumer(embedding_service)
    worker = OutboxWorker(engine, consumer=consumer)

consumer 回调签名：(event_type, payload) → 成功返回 None，失败抛异常（HIGH-01 路由真源）。
"""

from __future__ import annotations

import logging
from typing import Any, Callable, Dict, Optional

from embedding.cache_invalidator import CacheInvalidator, DeletionEvent, ForgetMode, TargetType
from embedding.embedding_service import EmbeddingService

logger = logging.getLogger(__name__)

# Outbox 事件类型常量
# 权威生产事件类型为 D 轨 Forget Executor 入队的 `forget.executed`
# （memory-service/db/repositories.py EVENT_FORGET_EXECUTED）；
# `memory.deletion` / `deletion` 为向后兼容的别名（D10A 早期契约）。
EVENT_DELETION = "memory.deletion"
EVENT_FORGET_EXECUTED = "forget.executed"
# 合法删除事件类型集合（跨版本兼容）
DELETION_EVENT_TYPES = frozenset({EVENT_DELETION, EVENT_FORGET_EXECUTED, "deletion"})

# Outbox 消费回调类型：(event_type, payload) → 成功返回 None，失败抛异常（HIGH-01 路由真源）
EventConsumer = Callable[[str, Dict[str, Any]], None]


def build_deletion_consumer(
    embedding_service: EmbeddingService,
) -> EventConsumer:
    """构造 Outbox 删除事件消费者。

    Args:
        embedding_service: EmbeddingService 实例（含已接线的 CacheInvalidator）。

    Returns:
        consumer 回调（(event_type, payload) → None/异常）。

    Payload 格式：
        {
            "event_id": str,
            "user_id": str,
            "target_type": str (TargetType 枚举名),
            "content_hashes": list[str],
            "content_fingerprints": list[str],
            "forget_mode": str (ForgetMode 枚举名),
        }
    """
    if embedding_service.invalidator is None:
        logger.warning(
            "CacheInvalidator 未接线（invalidator is None），"
            "删除事件 consumer 将始终失败"
        )
    else:
        logger.info(
            "Outbox 删除事件 consumer 已注册（invalidator 已就绪）"
        )

    def _consumer(event_type: str, payload: Dict[str, Any]) -> None:
        # HIGH-01：event_type 由 worker 从 outbox.event_type 独立列显式传入（路由真源），
        # 不再依赖 payload 注入；payload 内嵌 event_type 若与显式值不一致则 fail-closed。
        embedded = payload.get("event_type")
        if embedded is not None and str(embedded) != event_type:
            raise ValueError(
                f"outbox event_type 与 payload 不一致: db={event_type!r} payload={embedded!r}"
            )
        if event_type in DELETION_EVENT_TYPES:
            _handle_deletion_payload(payload, embedding_service)
        else:
            raise ValueError(f"unknown outbox event_type: {event_type!r}")

    return _consumer


def _handle_deletion_payload(
    payload: Dict[str, Any],
    embedding_service: EmbeddingService,
) -> None:
    """处理删除事件 payload。"""
    if embedding_service.invalidator is None:
        raise RuntimeError(
            "CacheInvalidator not initialized — call set_extraction_provider() first"
        )

    event_id = payload.get("event_id", "")
    if not event_id:
        raise ValueError("deletion payload missing event_id")

    user_id = payload.get("user_id", "")
    content_hashes = payload.get("content_hashes") or []
    content_fingerprints = payload.get("content_fingerprints") or []

    target_type_str = payload.get("target_type", "event")
    if not isinstance(target_type_str, str) or target_type_str not in TargetType._value2member_map_:
        raise ValueError(f"invalid target_type: {target_type_str!r}")
    target_type = TargetType(target_type_str)

    forget_mode_str = payload.get("forget_mode", "single_item")
    if not isinstance(forget_mode_str, str) or forget_mode_str not in ForgetMode._value2member_map_:
        raise ValueError(f"invalid forget_mode: {forget_mode_str!r}")
    forget_mode = ForgetMode(forget_mode_str)

    event = DeletionEvent(
        event_id=event_id,
        user_id=user_id,
        target_type=target_type,
        content_hashes=content_hashes,
        content_fingerprints=content_fingerprints,
        forget_mode=forget_mode,
    )

    result = embedding_service.handle_deletion_event(event)
    if not result.get("ok"):
        logger.error(
            "删除事件处理失败: event_id=%s result=%s", event_id, result
        )
        raise RuntimeError(f"deletion event failed: {result.get('error', 'unknown')}")

    logger.info(
        "删除事件处理完成: event_id=%s embedding_invalidated=%d "
        "extraction_invalidated=%d dedup=%s",
        event_id,
        result.get("embedding_invalidated", 0),
        result.get("extraction_invalidated", 0),
        result.get("dedup", False),
    )
